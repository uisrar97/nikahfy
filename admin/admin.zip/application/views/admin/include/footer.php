<style>
.cropmodal{
	z-index:9999 !important;
}
</style>
<div class="modal fade bs-example-modal-lg gallerymodal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" style="color: #337ab7; opacity: 1; font-size: 15px; margin-top: 5px;"><span aria-hidden="true">Add</span></button>
				<h4 class="modal-title" id="myModalLabel">Upload Images</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-md-3" style="border-right: 1px solid darkgray;text-align:center;">
						<label class="label" data-toggle="tooltip" title="Upload File Here">
							<img class="rounded" id="avatar"
							src="<?php echo base_url().'assets/images/upl.png'?>" alt="avatar" style="width: 160px; height: 160px">
							<input type="file" class="sr-only" id="input" name="image" accept="image/*">
						</label>
					</div>
					<div class="col-md-9">
						<div class="row gallerylist" style="margin-left: 10px;min-height: 160px;overflow:auto;"></div>
					</div>
				</div>
				<div class="row" style="text-align: center;background: #666;margin-top: 5px;color: #fff;">
					<div class="col-md-3">
						<div class="left-side-image-gallery-text">Upload a custom image</div>
					</div>
					<div class="col-md-9">
						<div class="right-side-image-gallery-text">Or choose a photo from CenterSquare stock photo collection to attach to your promotion.</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="modal fade bs-example-modal-lg gallerymodal1" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" style="color: #337ab7; opacity: 1; font-size: 15px; margin-top: 5px;"><span aria-hidden="true">Add</span></button>
				<h4 class="modal-title" id="myModalLabel">Upload Images</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-md-3" style="border-right: 1px solid darkgray;text-align:center;">
						<label class="label" data-toggle="tooltip" title="Upload File Here">
							<img class="rounded" id="avatar1"
							src="<?php echo base_url().'assets/images/upl.png'?>" alt="avatar" style="width: 160px; height: 160px">
							<input type="file" class="sr-only" id="input1" name="image" accept="image/*">
							<input type="hidden" id="loyalclass" name="loyalclass">
							<input type="hidden" id="goalclass" name="goalclass">
						</label>
					</div>
					<div class="col-md-9">
						<div class="row gallerylist1" style="margin-left: 10px;min-height: 160px;overflow:auto;"></div>
					</div>
				</div>
				<div class="row" style="text-align: center;background: #666;margin-top: 5px;color: #fff;">
					<div class="col-md-3">
						<div class="left-side-image-gallery-text">Upload a custom image</div>
					</div>
					<div class="col-md-9">
						<div class="right-side-image-gallery-text">Or choose a photo from CenterSquare stock photo collection to attach to your promotion.</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<footer>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="col-md-4 col-sm-4 col-xs-12">
               <a href="http://plandstudios.com/"> powered By Plan D Studios</a>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                For email support, contact support@Mountexgroup.com
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <p class="pull-right"> MountexGroup.</p>

            </div>
        </div>
    </div>
   <!-- <div class="pull-left">

    </div>
    <div class="pull-right">

    </div>-->
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>
<script type="text/javascript">
    $(document).ajaxStart(function(){
        $('#loader').show();
    }).ajaxStop(function(){
        $('#loader').hide();
    });
$(document).ready(function () {

    $('body').on('click','#english',function(){
        var lang = 'english';
        $.ajax({
            url:"<?php echo base_url();?>admin/Dashboard/change_lang/"+lang,
            success:function(response){

               location.reload();

            }

        });
    });
    $('body').on('click','#german',function(){
        var lang = 'german';
        $.ajax({
            url:"<?php echo base_url();?>admin/Dashboard/change_lang/"+lang,
            success:function(response){

                location.reload();

            }

        });
    });
});
</script>
<!-- jQuery -->

<!-- Bootstrap -->
<script src="<?php echo base_url()?>assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url()?>assets/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="<?php echo base_url()?>assets/vendors/nprogress/nprogress.js"></script>
<!-- Chart.js -->
<script src="<?php echo base_url()?>assets/vendors/Chart.js/dist/Chart.min.js"></script>
<!-- gauge.js -->
<script src="<?php echo base_url()?>assets/vendors/gauge.js/dist/gauge.min.js"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo base_url()?>assets/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="<?php echo base_url()?>assets/vendors/iCheck/icheck.min.js"></script>
<!-- Skycons -->
<script src="<?php echo base_url()?>assets/vendors/skycons/skycons.js"></script>
<script src="<?php echo base_url()?>assets/vendors/validator/validator.js"></script>
<!-- Flot -->
<script src="<?php echo base_url()?>assets/vendors/Flot/jquery.flot.js"></script>
<script src="<?php echo base_url()?>assets/vendors/Flot/jquery.flot.pie.js"></script>
<script src="<?php echo base_url()?>assets/vendors/Flot/jquery.flot.time.js"></script>
<script src="<?php echo base_url()?>assets/vendors/Flot/jquery.flot.stack.js"></script>
<script src="<?php echo base_url()?>assets/vendors/Flot/jquery.flot.resize.js"></script>
<script src="<?php echo base_url()?>assets/vendors/switchery/dist/switchery.min.js"></script>
<!-- Flot plugins -->
<script src="<?php echo base_url()?>assets/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
<script src="<?php echo base_url()?>assets/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/flot.curvedlines/curvedLines.js"></script>
<!-- DateJS -->
<script src="<?php echo base_url()?>assets/vendors/DateJS/build/date.js"></script>
<!-- JQVMap -->
<script src="<?php echo base_url()?>assets/vendors/jqvmap/dist/jquery.vmap.js"></script>
<script src="<?php echo base_url()?>assets/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
<script src="<?php echo base_url()?>assets/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
<script src="<?php echo base_url()?>assets/vendors/select2/dist/js/select2.full.min.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo base_url()?>assets/vendors/moment/min/moment.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
<script src="<?php echo base_url()?>assets/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/jszip/dist/jszip.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/pdfmake/build/pdfmake.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/pdfmake/build/vfs_fonts.js"></script>

<script src="<?php echo base_url()?>assets/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
<!--wizard jquery library-->

<script src="<?php echo base_url()?>assets/vendors/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
<script src="<?php echo base_url()?>assets/vendors/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
<!-- PNotify -->
<script src="<?php echo base_url()?>assets/vendors/pnotify/dist/pnotify.js"></script>
<script src="<?php echo base_url()?>assets/build/js/custom.js"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo base_url()?>assets/vendors/dropzone/dist/min/dropzone.min.js"></script>
<script src="<?php echo base_url()?>assets/vendors/clock/clock.js"></script>
<!-- <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&libraries=places&key=<?= GOOGLE_API_KEY?>"></script> -->
<!-- <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&libraries=places&key=AIzaSyCyrQXkRAMOxbeIY2bYRIEEqJaQNOFk7P0"></script> -->
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCyrQXkRAMOxbeIY2bYRIEEqJaQNOFk7P0&libraries=places&callback=initMap"
        async defer></script> -->
</body>
</html>
