<?php

require_once(APPPATH."third_party/emoji/Emoji.php");

class Myemoji extends Emoji {

}