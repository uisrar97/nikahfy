<?php

require_once(APPPATH."third_party/tcpdf/tcpdf.php");

class MYPDF extends TCPDF {

}