<?php
/**
 * Created by PhpStorm.
 * User: abc
 * Date: 11/27/2017
 * Time: 4:45 AM
 */
class Dashboard extends MY_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Sqa_model');

    }

    public function index(){
        $this->load->view('admin/dashboard');
    }

    public function logout(){
        $data= array('id',
            'name',
            'username',
            'email',
            'password',
            'contact',
            'phone',
            'status',
            'loggedin');
        $this->session->sess_destroy($data);
   /*     $expire= time()+(86400 * 30);
        $path='/';
        $domain = 'centersquare.plandstudios.com';
        $name='centersquare_username';
        $value='';
        setcookie ($name, $value, $expire, $path, $domain, $secure = false, $httponly = false);*/
        redirect('/');
    }


    public function change_lang($lang='')
    {
        $this->session->set_userdata('Language',$lang);
        echo 'changed';
    }


}


