<?php

/**
 * Created by PhpStorm.
 * User: abc
 * Date: 11/27/2017
 * Time: 4:45 AM
 */
class Appusers extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Sqa_model');

	}

	public function index()
	{

		$this->load->view('app/appusers');
	}


	public function get_appusers()
	{
		$i = 1;
		$pTable = 'users';
		$columns = array('*');
		$this->db->order_by('id DESC');
		$where = '';
		$data = $this->Sqa_model->get_joined_records($pTable, $columns, $joins = '', $where)->result();

		foreach ($data as $val) {
			if ($val->isActive == '1' && $val->isDeleted == '0') {
				$val->status = '<h4><span class="label label-success">Approved</span></h4>';
				$btnstatus = '<button title="Disapproved" type="button" class="btn btn-round btn-success btn-sm disapp" id="' . $val->id . '"><i class="fa fa-thumbs-o-up"></i></button>';
			} else {
				$val->status = '<h4><span class="label label-warning">Disapproved</span></h4>';
				$btnstatus = '<button title="Approved" type="button" class="btn btn-round btn-warning btn-sm app" id="' . $val->id . '"><i class="fa fa-thumbs-down"></i></button>';
			}

			$val->btn = '' . $btnstatus . '<button type="button" title="Delete" class="btn btn-round btn-danger btn-sm delete_cat" id="' . $val->id . '"><i class="fa fa-trash-o"></i></button>';
			$val->cnt = $i;
			$i++;
		}
		if (!empty($data)) {
			$data1 = array('data' => $data);
			print json_encode($data1);
		} else {
			$data1 = array('data' => array());
			print json_encode($data1);
		}
	}


	public function Delete_sub()
	{
		$id = $this->input->post('id');
		$table = 'centersq_categories';
		$where = array('id' => $id);
		$res = $this->Sqa_model->delete_records($table, $where);
		if ($res) {
			echo "yes";

		} else {
			echo "false";
		}
	}

	public function app_user_del()
	{
		$id = $this->input->post('id');
		$table = 'users';
		$where = array('id' => $id);
		$res = $this->Sqa_model->delete_records($table, $where);
		 $this->Sqa_model->delete_records('profiles_pro', array('pro_person_id'=>$id));
		if ($res) {
			echo "yes";

		} else {
			echo "false";
		}
	}

	public function Deactivate()
	{
		$id = $this->input->post('id');
		$res = $this->Sqa_model->update_records('users', array('isActive' => '0', 'isDeleted' => '1'), array('id' => $id));
		 $this->Sqa_model->update_records('profiles_pro', array('pro_status' => 0), array('pro_person_id' => $id));
		if ($res) {
			print json_encode("yes");
		} else {
			print json_encode("false");
		}
	}


	public function Activate()
	{
		$id = $this->input->post('id');
		$res = $this->Sqa_model->update_records('users', array('isActive' => '1', 'isDeleted' => '0'), array('id' => $id));
		$this->Sqa_model->update_records('profiles_pro', array('pro_status' => 1), array('pro_person_id' => $id));
		if ($res) {
			print json_encode("yes");
		} else {
			print json_encode("false");
		}
	}


}


