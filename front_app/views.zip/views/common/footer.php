<?php
$ci= &get_instance();
$setting=$ci->get_setting();

?>
</div>
<!--content ends-->

<!--footer started-->
<div class="footer-wraper">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="footer-text-wraper">
					<div class="footer-logo-wrp">
						<img src="<?php echo base_url()?>assets/images/logo.png" alt="">
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="footer-download-button"> <a href="https://play.google.com/store/apps/details?id=com.plandstudios.matrimonialapp"> <img src="<?php echo base_url()?>assets/images/appbutton.png" alt=""> </a> <!--<a href="#"> <img src="images/appbutton1.png" alt=""> </a>--> </div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="copyright-text-footer">
			<div class="row">
				<div class="col-md-4 col-sm-4 col-xs-12">
					<div class="copy-rigt"> Copyrights &copy; <?= date('Y')?> Nikahfy.<!--<br>
            Design by <a href="https://plandstudios.com">Plandstudios</a>--> </div>
				</div>
				<div class="col-md-8 col-sm-4 col-xs-12">
					<div class="footer-navigation">
						<ul>
							<li> <a href="<?php echo base_url()?>"> Home </a> </li>
							<li> <a href="<?= base_url().'pages/about-us'?>"> About </a> </li>
							<!-- <li> <a href="faqs.html"> Faqs </a> </li> -->
							<li> <a href="<?= base_url().'pages/contact-us'?>"> Contact </a> </li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--footer ends-->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script type="text/javascript" src="<?= base_url()?>assets/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script type="text/javascript" src="<?= base_url()?>assets/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
    $(document).ready(function () {

        $('.consend').click(function(e) {

            var validate=0;
            var name= $('#name').val();
            var email= $('#email').val();
            var message= $('#message').val();
            var qs= $('#qs').val();
            if(name==''){
                $('#name').css('border','1px solid red');
                validate=1;
            }else{
                $('#name').css('border','1px solid green');
            }
            if(email==''){
                $('#email').css('border','1px solid red');
                validate=1;
            }else{
                $('#email').css('border','1px solid green');
            }
            if(message==''){
                $('#message').css('border','1px solid red');
                validate=1;
            }else{
                $('#message').css('border','1px solid green');
            }
            if(validate==0) {
                $(this).prop('disabled',true);
                $('#pro').show();
                e.preventDefault();
                $.ajax({
                    url : "<?php echo base_url().'Home/contact_send_us'?>",
                    type: "POST",
                    data : {name:name,qs:qs,email:email, message:message},
                    dataType:"json",
                    success: function(res) {
                        if (res != 'false') {
                            swal("Thank you for trying to reach us. We will be in touch soon.");
                            $('#name').val('');
                            $('#qs').val('');
                            $('#email').val('');
                            $('#message').val('');
                            $('#contactform').trigger('reset');
                            $('.consend').prop('disabled',false);
                            $('#pro').hide();

                        } else {
                            swal("Please. Try Again!");
                        }

                    }

                });
            }

        });
        var trigger = $('.hamburger'),
            overlay = $('.overlay'),
            isClosed = false;

        trigger.click(function () {
            hamburger_cross();
        });

        function hamburger_cross() {

            if (isClosed == true) {
                overlay.hide();
                trigger.removeClass('is-open');
                trigger.addClass('is-closed');
                isClosed = false;
            } else {
                overlay.show();
                trigger.removeClass('is-closed');
                trigger.addClass('is-open');
                isClosed = true;
            }
        }

        $('[data-toggle="offcanvas"]').click(function () {
            $('#wrapper').toggleClass('toggled');
        });
    });
</script>
</body>
</html>
